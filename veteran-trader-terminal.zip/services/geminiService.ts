import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisData, Language } from "../types";

// Schema definition for structured output
const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    asset: { type: Type.STRING, description: "The name of the asset analyzed (e.g. BTC/USDT)" },
    currentPrice: { type: Type.STRING, description: "The current approximate price found via search" },
    marketStructure: { 
      type: Type.STRING, 
      enum: ["Trending Bullish", "Trending Bearish", "Ranging", "Correction"],
      description: "The overall market structure on Daily/H4"
    },
    marketStructureDetails: { type: Type.STRING, description: "Detailed analysis of the market structure and trend" },
    levels: {
      type: Type.OBJECT,
      properties: {
        supports: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Key support levels" },
        resistances: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Key resistance levels" },
        fibonacci: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Relevant Fib levels" }
      },
      required: ["supports", "resistances"]
    },
    technicals: {
      type: Type.OBJECT,
      properties: {
        ema: { type: Type.STRING, description: "Analysis of EMA 20, 50, 200" },
        momentum: { type: Type.STRING, description: "RSI/Stochastic analysis" },
        volume: { type: Type.STRING, description: "Volume profile and liquidity analysis" },
        volatility: { type: Type.STRING, description: "ATR or Bollinger Bands analysis" }
      },
      required: ["ema", "momentum", "volume", "volatility"]
    },
    setup: {
      type: Type.OBJECT,
      properties: {
        signal: { type: Type.STRING, enum: ["LONG", "SHORT", "NEUTRAL"] },
        entryZone: { type: Type.STRING, description: "Precise entry zone" },
        stopLoss: { type: Type.STRING, description: "Logical stop loss level" },
        takeProfits: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Minimum 3 TP targets" },
        riskRewardRatio: { type: Type.STRING, description: "Estimated R:R ratio" }
      },
      required: ["signal", "entryZone", "stopLoss", "takeProfits", "riskRewardRatio"]
    },
    veteranInsight: { type: Type.STRING, description: "A specific piece of advice, psychology tip, or 'trap' warning based on 30 years of experience." }
  },
  required: ["asset", "marketStructure", "marketStructureDetails", "levels", "technicals", "setup", "veteranInsight"]
};

export const analyzeAsset = async (assetName: string, language: Language): Promise<AnalysisData> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const languageInstruction = language === 'ID' 
    ? "Provide all analysis, explanations, and insights in Indonesian (Bahasa Indonesia). Keep technical terms (like 'Stop Loss', 'Entry', 'Bearish', 'Bullish', 'RSI') in English if commonly used, but explain the context in Indonesian."
    : "Provide all analysis in English.";

  const prompt = `
    Role: 30-Year Veteran Market Strategist & Professional Trader.
    Task: Scan and analyze the asset: ${assetName}.
    
    Use Google Search to find the LATEST price action, news, and market data for ${assetName} as of today.
    
    Language Requirement: ${languageInstruction}
    
    Analysis Requirements:
    1. Market Structure & Trend (Daily/H4).
    2. Key Levels (Supply/Demand, S/R, Fibs).
    3. Technical Indicators (EMA 20/50/200, RSI, Volume).
    4. Volatility (ATR/BB).
    5. Risk-to-Reward Trade Setup (Entry, SL, 3 TPs).
    6. Veteran Insight (Psychology/Traps).
    
    Prioritize capital preservation. If the setup is not high probability, mark signal as NEUTRAL.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview", // Using Pro for better reasoning capabilities
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const data = JSON.parse(text) as AnalysisData;

    // Extract grounding URLs if available
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const groundingUrls: string[] = [];
    
    if (groundingChunks) {
        groundingChunks.forEach((chunk: any) => {
            if (chunk.web?.uri) {
                groundingUrls.push(chunk.web.uri);
            }
        });
    }
    
    data.groundingUrls = Array.from(new Set(groundingUrls)).slice(0, 5); // Dedup and limit

    return data;
  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};